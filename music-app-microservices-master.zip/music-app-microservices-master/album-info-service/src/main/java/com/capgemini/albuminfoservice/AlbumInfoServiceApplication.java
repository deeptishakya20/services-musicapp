package com.capgemini.albuminfoservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlbumInfoServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlbumInfoServiceApplication.class, args);
	}

}
